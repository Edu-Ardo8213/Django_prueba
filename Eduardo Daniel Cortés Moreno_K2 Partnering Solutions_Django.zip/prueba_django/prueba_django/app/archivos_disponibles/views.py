from django.views.generic import View
from django.shortcuts import render, redirect
from pathlib import Path
from django.conf import settings
import json
from os import listdir
import os
from app.archivos_disponibles.models import Registro_archivos
from django.http import HttpResponse
import csv
import pandas as pd


def archivos(request):
    lista=[]
    for file in os.listdir("C:/prueba_django/prueba_django/data_files/"):
        if file.endswith(".json"):
            with open("C:/prueba_django/prueba_django/data_files/"+file, 'r') as j:
                json_data = json.load(j)
                pathFile="C:/prueba_django/prueba_django/data_files/"+json_data["client_filename"]
                df = pd.read_csv(pathFile, index_col=0,encoding='latin-1')
                json_data["min_date"]=min(df[json_data["date_col"]])
                json_data["max_date"]=max(df[json_data["date_col"]])
                lista.append(json_data)
    return render(request,"archivos_disponibles/archivos.html",{"lista":lista})


def exportar_archivo(request,client_filename):
	b = Registro_archivos(file_name=client_filename)
	b.save()
	pathFile="C:/prueba_django/prueba_django/data_files/"+client_filename
	with open(pathFile, 'rb') as fh:
		response = HttpResponse(fh.read(), content_type='text/csv')
		response['Content-Disposition'] = 'attachment; filename=' + os.path.basename(pathFile)
	return response
