from django.contrib import admin
from .models import Registro_archivos

class Registro_archivosAdmin(admin.ModelAdmin):
    readonly_fields=('downloadTime',)
    list_display=('file_name','downloadTime')
admin.site.register(Registro_archivos,Registro_archivosAdmin)