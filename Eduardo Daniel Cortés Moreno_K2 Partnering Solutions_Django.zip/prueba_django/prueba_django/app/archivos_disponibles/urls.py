from django.urls import path
from django.conf.urls import url, include
from django.contrib.auth.decorators import login_required
from app.archivos_disponibles.views import archivos, exportar_archivo

urlpatterns = [
	#path('', (index), name='index'),
	path('archivos', archivos, name='archivos'),
	path('exportar_archivo/<client_filename>/', exportar_archivo, name='exportar_archivo')








	]