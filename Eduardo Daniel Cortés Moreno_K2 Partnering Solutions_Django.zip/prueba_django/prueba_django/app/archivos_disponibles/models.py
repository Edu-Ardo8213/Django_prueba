from django.db import models



class Registro_archivos(models.Model):
	file_name = models.CharField(max_length=200,verbose_name="Nombre de Archivo")
	downloadTime=models.DateTimeField( auto_now_add=True,verbose_name='Fecha de Descarga')

	def __str__(self):
		return '{}'.format(self.file_name)