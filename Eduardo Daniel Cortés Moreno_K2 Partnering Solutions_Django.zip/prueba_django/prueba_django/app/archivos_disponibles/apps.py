from django.apps import AppConfig


class ArchivosDisponiblesConfig(AppConfig):
    name = 'archivos_disponibles'
